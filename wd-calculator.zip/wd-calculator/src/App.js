import { useState } from "react";

const BOXES = [
  { label: "24x18x18", dims: "61x46x46", units: 250, lbs: 50 },
  { label: "18x18x18", dims: "46x46x46", units: 200, lbs: 40 },
  { label: "16x16x16", dims: "41x41x41", units: 150, lbs: 30 },
  { label: "14x14x14", dims: "36x36x36", units: 120, lbs: 22 },
  { label: "12x12x12", dims: "30x30x30", units: 50,  lbs: 10 },
  { label: "12x10x8",  dims: "30x25x20", units: 30,  lbs: 6  },
  { label: "Medium",   dims: "25x20x15", units: 12,  lbs: 2  },
  { label: "Small",    dims: "20x15x10", units: 8,   lbs: 1  },
];

const PRODUCTS = {
  CRAG: { code: "CR2003", color: "#e86c2f", unitLbs: 0.5, flexible: true },
  HGM:  { code: "HGM101", color: "#2f8fe8", unitLbs: 2,   flexible: false, maxPerBox: 24, fullBox: { dims: "46x46x46", lbs: 32 } },
  CAB:  { code: "CAB102", color: "#2fc47a", unitLbs: 2,   flexible: false, maxPerBox: 24, fullBox: { dims: "46x46x46", lbs: 36 } },
};

const SMALL_BOXES = [
  { maxUnits: 24, dims: "41x41x41", baseLbs: 4 },
  { maxUnits: 12, dims: "30x30x30", baseLbs: 2 },
  { maxUnits: 6,  dims: "25x20x15", baseLbs: 1 },
];

function lbsToKg(lbs) { return Math.round(lbs * 0.453592 * 10) / 10; }

function formatBox(dims, netKg, count) {
  const grossKg = Math.ceil(netKg + 0.3);
  return `${dims} @ ${netKg}kg net/${grossKg}kg gross (${count} box${count > 1 ? "es" : ""}, no pallet)`;
}

function calcCRAG(qty) {
  let remaining = qty;
  const lines = [];

  for (const box of BOXES) {
    if (remaining <= 0) break;
    const count = Math.floor(remaining / box.units);
    if (count > 0) {
      const leftover = remaining - count * box.units;
      if (leftover <= 40) {
        const extraLbs = Math.ceil(leftover / 10);
        const kg = lbsToKg(box.lbs + extraLbs);
        lines.push(formatBox(box.dims, kg, count));
        remaining = 0;
      } else {
        const kg = lbsToKg(box.lbs);
        lines.push(formatBox(box.dims, kg, count));
        remaining -= count * box.units;
      }
    }
  }

  // any tiny remainder
  if (remaining > 0) {
    const last = BOXES[BOXES.length - 1];
    const kg = lbsToKg(last.lbs);
    lines.push(formatBox(last.dims, kg, 1));
  }

  return lines;
}

function calcFixed(qty, product) {
  const p = PRODUCTS[product];
  const fullCount = Math.floor(qty / p.maxPerBox);
  const leftover = qty % p.maxPerBox;
  const lines = [];

  if (fullCount > 0) {
    lines.push(formatBox(p.fullBox.dims, lbsToKg(p.fullBox.lbs), fullCount));
  }

  if (leftover > 0) {
    let chosen = SMALL_BOXES[0];
    for (const sb of SMALL_BOXES) {
      if (leftover <= sb.maxUnits) chosen = sb;
    }
    const lbs = chosen.baseLbs + leftover * p.unitLbs;
    lines.push(formatBox(chosen.dims, lbsToKg(lbs), 1));
  }

  return lines;
}

export default function App() {
  const [entries, setEntries] = useState([{ product: "CRAG", qty: "" }]);
  const [results, setResults] = useState([]);
  const [copied, setCopied] = useState(false);

  const addEntry = () => setEntries([...entries, { product: "CRAG", qty: "" }]);
  const removeEntry = (i) => setEntries(entries.filter((_, idx) => idx !== i));
  const updateEntry = (i, field, val) => {
    const next = [...entries];
    next[i] = { ...next[i], [field]: field === "qty" ? (val === "" ? "" : parseInt(val) || "") : val };
    setEntries(next);
  };

  const handleCalc = () => {
    const valid = entries.filter(e => e.qty > 0);
    const res = valid.map(({ product, qty }) => ({
      product, qty,
      code: PRODUCTS[product].code,
      color: PRODUCTS[product].color,
      lines: product === "CRAG" ? calcCRAG(qty) : calcFixed(qty, product),
    }));
    setResults(res);
  };

  const allText = results.flatMap(r => r.lines.map(l => `Estimated W&D: ${l}`)).join("\n");

  const handleCopy = () => {
    navigator.clipboard.writeText(allText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const s = {
    page: { minHeight: "100vh", background: "#0f0f0f", fontFamily: "'Courier New', monospace", color: "#f0ede6", padding: "40px 20px" },
    wrap: { maxWidth: 700, margin: "0 auto" },
    label: { fontSize: 11, letterSpacing: 6, color: "#666", marginBottom: 8 },
    title: { fontSize: 42, fontWeight: 900, margin: 0, lineHeight: 1, background: "linear-gradient(135deg,#e8a83a,#e8602f)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" },
    sub: { fontSize: 12, color: "#555", marginTop: 6, marginBottom: 40 },
    row: { display: "flex", gap: 10, alignItems: "center", background: "#1a1a1a", border: "1px solid #2a2a2a", borderRadius: 8, padding: "12px 16px" },
    select: { background: "#111", border: "1px solid #333", color: "#f0ede6", padding: "8px 12px", borderRadius: 6, fontSize: 13, fontFamily: "'Courier New', monospace", cursor: "pointer", flex: 1 },
    input: { background: "#111", border: "1px solid #333", color: "#f0ede6", padding: "8px 12px", borderRadius: 6, fontSize: 13, fontFamily: "'Courier New', monospace", width: 120, outline: "none" },
    removeBtn: { background: "none", border: "1px solid #333", color: "#666", width: 32, height: 32, borderRadius: 6, cursor: "pointer", fontSize: 16 },
    addBtn: { background: "#1a1a1a", border: "1px solid #333", color: "#888", padding: "10px 18px", borderRadius: 6, cursor: "pointer", fontFamily: "'Courier New', monospace", fontSize: 12, letterSpacing: 1 },
    calcBtn: { background: "linear-gradient(135deg,#e8a83a,#e8602f)", border: "none", color: "#fff", fontWeight: 900, padding: "10px 28px", borderRadius: 6, cursor: "pointer", fontFamily: "'Courier New', monospace", fontSize: 13, letterSpacing: 2, flex: 1 },
  };

  return (
    <div style={s.page}>
      <div style={s.wrap}>
        <div style={s.label}>SHIPPING TOOL</div>
        <h1 style={s.title}>W&D CALCULATOR</h1>
        <div style={s.sub}>Weights & Dimensions Estimator</div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 24 }}>
          {entries.map((e, i) => (
            <div key={i} style={s.row}>
              <select value={e.product} onChange={ev => updateEntry(i, "product", ev.target.value)} style={s.select}>
                {Object.entries(PRODUCTS).map(([k, v]) => (
                  <option key={k} value={k}>{k} ({v.code})</option>
                ))}
              </select>
              <input type="number" placeholder="Quantity" value={e.qty} onChange={ev => updateEntry(i, "qty", ev.target.value)} style={s.input} />
              {entries.length > 1 && <button onClick={() => removeEntry(i)} style={s.removeBtn}>×</button>}
            </div>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, marginBottom: 32 }}>
          <button onClick={addEntry} style={s.addBtn}>+ ADD PRODUCT</button>
          <button onClick={handleCalc} style={s.calcBtn}>CALCULATE</button>
        </div>

        {results.length > 0 && (
          <div style={{ borderTop: "1px solid #2a2a2a", paddingTop: 28 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 11, letterSpacing: 4, color: "#555" }}>RESULTS</div>
              <button onClick={handleCopy} style={{ background: copied ? "#2a3d2a" : "#1a1a1a", border: `1px solid ${copied ? "#2f8f4a" : "#333"}`, color: copied ? "#2fc47a" : "#666", padding: "6px 14px", borderRadius: 5, cursor: "pointer", fontFamily: "'Courier New', monospace", fontSize: 11, letterSpacing: 1, transition: "all 0.2s" }}>
                {copied ? "✓ COPIED" : "COPY ALL"}
              </button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {results.map((r, i) => (
                <div key={i} style={{ background: "#141414", border: "1px solid #222", borderLeft: `3px solid ${r.color}`, borderRadius: 8, padding: "16px 20px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                    <span style={{ color: r.color, fontWeight: 700, fontSize: 14 }}>{r.product}</span>
                    <span style={{ color: "#444", fontSize: 11 }}>{r.code}</span>
                    <span style={{ color: "#444", fontSize: 11, marginLeft: "auto" }}>QTY: {r.qty.toLocaleString()}</span>
                  </div>
                  {r.lines.map((line, j) => (
                    <div key={j} style={{ fontFamily: "'Courier New', monospace", fontSize: 13, color: "#d4d0c8", lineHeight: 1.8, background: "#0f0f0f", borderRadius: 4, padding: "8px 12px", marginBottom: j < r.lines.length - 1 ? 6 : 0 }}>
                      <span style={{ color: "#555" }}>Estimated W&D: </span>{line}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}

        <div style={{ marginTop: 48, borderTop: "1px solid #1a1a1a", paddingTop: 20 }}>
          <div style={{ fontSize: 10, letterSpacing: 4, color: "#333", marginBottom: 12 }}>PRODUCT REFERENCE</div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {Object.entries(PRODUCTS).map(([k, v]) => (
              <div key={k} style={{ background: "#141414", border: "1px solid #222", borderRadius: 6, padding: "8px 14px", fontSize: 11, color: "#555" }}>
                <span style={{ color: v.color }}>{k}</span> · {v.code} · {v.unitLbs}lb/unit
                {v.flexible ? " · flexible packing" : ` · max ${v.maxPerBox}/box`}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
